import { body, param, validationResult } from 'express-validator'
import { ErrorHandler } from '../middlewares/error.js'

export const registerValidator = () => [
  body('name', 'Please Enter Name').notEmpty(),
  body('username', 'Please Enter Username').notEmpty(),
  body('bio', 'Please Enter Bio').notEmpty(),
  body('password', 'Please Enter Password').notEmpty(),
]

export const loginValidator = () => [
  body('username', 'Please Enter Username').notEmpty(),
  body('password', 'Please Enter Password').notEmpty(),
]

export const newGroupValidator = () => [
  body('name', 'Please Enter Name').notEmpty(),
]

export const addMemberValidator = () => [
  body('chatId', 'Please Enter Chat ID').notEmpty(),
  body('members')
    .notEmpty()
    .withMessage('Please Enter Members')
    .isArray({ min: 1, max: 97 })
    .withMessage('Members must be 1-97'),
]

export const removeMemberValidator = () => [
  body('chatId', 'Please Enter Chat ID').notEmpty(),
  body('userId', 'Please Enter User ID').notEmpty(),
]

export const sendAttachmentsValidator = () => [
  body('chatId', 'Please Enter Chat ID').notEmpty(),
]

export const chatIdValidator = () => [
  param('id', 'Please Enter Chat ID').notEmpty(),
]

export const renameValidator = () => [
  param('id', 'Please Enter Chat ID').notEmpty(),
  body('name', 'Please Enter New Name').notEmpty(),
]

export const sendRequestValidator = () => [
  body('userId', 'Please Enter User ID').notEmpty(),
]

export const acceptRequestValidator = () => [
  body('requestId', 'Please Enter Request ID').notEmpty(),
  body('accept')
    .notEmpty()
    .withMessage('Please Add Accept')
    .isBoolean()
    .withMessage('Accept must be a boolean'),
]

export const adminLoginValidator = () => [
  body('secret', 'Please Enter Secret Key').notEmpty(),
]

export const validateHandler = (req, res, next) => {
  const errors = validationResult(req)

  const errorMessages = errors
    .array()
    .map((error) => error.msg)
    .join(', ')

  if (errors.isEmpty()) {
    return next()
  } else {
    next(new ErrorHandler(errorMessages, 400))
  }
}
