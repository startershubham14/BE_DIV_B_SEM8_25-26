# app.py - WITH MANUAL PROFANITY FILTER
"""
Flask API for Toxic Comment Detection
Compatible with TensorFlow 2.13-2.15
"""

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'  # Reduce TF warnings

import numpy as np
import pickle
import json
import re

# TensorFlow with error handling
try:
    import tensorflow as tf
    from tensorflow import keras
    print(f"TensorFlow version: {tf.__version__}")
except ImportError:
    print("ERROR: TensorFlow not installed!")
    exit(1)

# PyTorch
import torch
from transformers import DistilBertTokenizer, DistilBertForSequenceClassification

from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# ============================================================================
# PROFANITY FILTER - MANUAL WORD LIST
# ============================================================================

class ProfanityFilter:
    """Manual profanity filter for common toxic words in multiple languages"""
    
    def __init__(self):
        # ENGLISH profanity and slurs
        self.bad_words = {
            # Profanity
            'fuck', 'fucking', 'fucker', 'fucked', 'fck', 'fuk', 'fucks', 'fuckin',
            'shit', 'shitting', 'bullshit', 'shitty', 'shitter', 'shithead',
            'ass', 'asshole', 'arse', 'arsehole', 'asshat', 'asses', 'arses',
            'bitch', 'bitching', 'bitchy', 'bitches', 'bastard', 'bastards',
            'damn', 'damned', 'dammit', 'goddamn',
            'cunt', 'cock', 'dick', 'dickhead', 'prick', 'dicks', 'cocks',
            'pussy', 'twat', 'wank', 'wanker', 'pussies',
            'hell', 'bloody', 'crap', 'crappy', 'bullcrap',
            'motherfucker', 'mofo', 'mf', 'motherfucking',
            'bollocks', 'bugger', 'shag', 'slag',
            
            # Slurs and hate speech
            'retard', 'retarded', 'retards',
            'nigger', 'nigga', 'negro', 'nig', 'niggas', 'niggers',
            'chink', 'gook', 'spic', 'wetback', 'beaner',
            'kike', 'faggot', 'fag', 'dyke', 'tranny', 'shemale',
            'raghead', 'towelhead', 'sandnigger',
            
            # Offensive terms
            'whore', 'slut', 'skank', 'hoe', 'hooker', 'sluts', 'whores',
            'rape', 'rapist', 'molest', 'raping', 'raped',
            'kys', 'kill yourself', 'killurself',
            
            # Variations
            'f*ck', 'sh*t', 'a$', 'b!tch', 'fvck', 'shyt', 'azz', 'biatch',
            
            # HINDI/URDU
            'chutiya', 'chutiye', 'chutia', 'gandu', 'gand', 'gaandu',
            'madarchod', 'maderchod', 'mc', 'behenchod', 'bc', 'behen chod',
            'bhosdike', 'bhosdi ke', 'bsdk', 'bhosda', 'bhosad',
            'lund', 'loda', 'lawda', 'lauda', 'lunn',
            'choot', 'chut', 'chod', 'chodna', 'chodu',
            'kamina', 'kamine', 'kamini', 'kutte', 'kutta', 'saala', 'sala',
            'randi', 'raand', 'rundi', 'harami', 'haramzada', 'haramzadi',
            'bhenchod', 'benchod', 'behen ke lode', 'teri maa', 'teri behen',
            
            # SPANISH
            'puta', 'puto', 'putas', 'putos', 'hijo de puta', 'hijueputa',
            'mierda', 'cagada', 'pinche', 'pendejo', 'pendeja',
            'cabron', 'cabrón', 'cabrona', 'chingada', 'chingar', 'chingado',
            'verga', 'vergas', 'coño', 'cono', 'joder', 'carajo',
            'maricon', 'maricón', 'marica', 'panocha', 'concha',
            
            # FRENCH
            'putain', 'pute', 'salope', 'connard', 'connasse',
            'merde', 'chier', 'foutre', 'enculé', 'enculer',
            'con', 'conne', 'bite', 'couilles', 'ta gueule',
            
            # GERMAN
            'scheiße', 'scheisse', 'scheiss', 'arschloch', 'arsch',
            'fotze', 'fick', 'ficken', 'verfickt', 'hurensohn',
            'schlampe', 'wichser', 'schwanz', 'muschi',
            
            # ITALIAN
            'cazzo', 'coglione', 'coglioni', 'merda', 'stronzo', 'stronza',
            'puttana', 'troia', 'figa', 'fica', 'vaffanculo', 'fanculo',
            
            # PORTUGUESE
            'porra', 'caralho', 'foda', 'foder', 'puta', 'merda',
            'cu', 'buceta', 'viado', 'filho da puta', 'fdp',
            
            # RUSSIAN (transliterated)
            'blyat', 'blyad', 'suka', 'pizdec', 'pizda', 'hui', 'khuy',
            'mudak', 'govno', 'chert', 'debil', 'idi nahui',
            
            # ARABIC (transliterated)
            'sharmouta', 'sharmuta', 'kos', 'koss', 'ayr', 'hmar',
            'kalb', 'kus omak', 'ibn sharmouta',
            
            # CHINESE (pinyin)
            'cao', 'ta ma de', 'ni ma', 'sha bi', 'bi', 'ji ba',
            'gun', 'wang ba dan', 'hun dan',
            
            # JAPANESE (romanized)
            'baka', 'kuso', 'shine', 'aho', 'chikushou',
            'kichigai', 'temee', 'kisama',
            
            # KOREAN (romanized)
            'sibal', 'ssibal', 'gaeseki', 'jot', 'jaji', 'boji',
            'byungshin', 'michin', 'ssekki',
            
            # DUTCH
            'kut', 'tering', 'kanker', 'lul', 'hoer', 'klootzak',
            'godverdomme', 'godver', 'shit', 'flikker',
            
            # POLISH
            'kurwa', 'kurva', 'chuj', 'pizda', 'pierdol', 'dupa',
            'gowno', 'skurwysyn', 'jebać',
            
            # TURKISH
            'amk', 'orospu', 'sik', 'göt', 'bok', 'piç', 'puşt',
            'yarak', 'amcık', 'siktir',
            
            # MARATHI
            'jhavadya', 'zhavadya', 'gadhav', 'khanki', 'rande',
            'bayko', 'lavdya', 'pucchi',
            
            # TAMIL
            'otha', 'oombu', 'punda', 'poolu', 'koothi', 'thevidiya',
            
            # TELUGU
            'dengey', 'puka', 'modda', 'bosudi', 'lanjakodaka',
        }
        
        # Compile regex patterns for variations
        self.patterns = self._create_patterns()
    
    def _create_patterns(self):
        """Create regex patterns to catch variations"""
        patterns = []
        
        for word in self.bad_words:
            # Match exact word with word boundaries
            pattern = r'\b' + re.escape(word) + r'\b'
            patterns.append(re.compile(pattern, re.IGNORECASE))
            
            # Match with leetspeak substitutions (a->4, e->3, i->1, o->0, s->5)
            leet_word = word
            leet_word = leet_word.replace('a', '[a4@]')
            leet_word = leet_word.replace('e', '[e3]')
            leet_word = leet_word.replace('i', '[i1!]')
            leet_word = leet_word.replace('o', '[o0]')
            leet_word = leet_word.replace('s', '[s5$]')
            patterns.append(re.compile(r'\b' + leet_word + r'\b', re.IGNORECASE))
        
        return patterns
    
    def contains_profanity(self, text):
        """Check if text contains profanity"""
        text_lower = text.lower()
        
        # Quick check: exact matches
        words = re.findall(r'\b\w+\b', text_lower)
        if any(word in self.bad_words for word in words):
            return True
        
        # Pattern check: catch variations
        for pattern in self.patterns:
            if pattern.search(text):
                return True
        
        return False
    
    def censor_profanity(self, text):
        """Censor profanity in text"""
        censored = text
        
        # Find all profane words
        words = text.split()
        censored_words = []
        
        for word in words:
            # Skip mentions, hashtags, URLs
            if word.startswith(('@', '#', 'http')):
                censored_words.append(word)
                continue
            
            # Check if word is profane
            is_bad = False
            word_clean = re.sub(r'[^\w]', '', word).lower()
            
            if word_clean in self.bad_words:
                is_bad = True
            else:
                # Check patterns
                for pattern in self.patterns:
                    if pattern.search(word):
                        is_bad = True
                        break
            
            if is_bad and len(word) > 2:
                # Censor: keep first and last letter
                if len(word) == 3:
                    censored_words.append(word[0] + '*' + word[-1])
                else:
                    censored_words.append(word[0] + '*' * (len(word) - 2) + word[-1])
            else:
                censored_words.append(word)
        
        return ' '.join(censored_words)
    
    def get_toxicity_level(self, text):
        """Get toxicity level based on profanity count"""
        text_lower = text.lower()
        count = 0
        
        # Count profane words
        words = re.findall(r'\b\w+\b', text_lower)
        for word in words:
            if word in self.bad_words:
                count += 1
        
        # Check patterns
        for pattern in self.patterns:
            matches = pattern.findall(text)
            count += len(matches)
        
        if count == 0:
            return 0.0
        elif count == 1:
            return 0.3
        elif count == 2:
            return 0.5
        elif count == 3:
            return 0.7
        else:
            return 0.9

# Initialize profanity filter
profanity_filter = ProfanityFilter()

# ============================================================================
# ENSEMBLE MODEL - WITH COMPATIBILITY FIXES
# ============================================================================

class ToxicCommentEnsemble:
    """Ensemble model with TensorFlow compatibility fixes"""
    
    def __init__(self, model_dir='ensemble_models'):
        print("\n" + "=" * 60)
        print("Loading Ensemble Model...")
        print("=" * 60)
        
        # Load config
        with open(f'{model_dir}/ensemble_config.json', 'r') as f:
            self.config = json.load(f)
        print(f"Method: {self.config['best_method']}")
        
        # Load CNN-GRU with compatibility handling
        print("\n[1/3] Loading CNN-GRU model...")
        self.cnn_model = self._load_cnn_model_compatible(model_dir)
        
        with open(f'{model_dir}/cnn_gru/tokenizer.pkl', 'rb') as f:
            self.cnn_tokenizer = pickle.load(f)
        print("✓ CNN-GRU loaded")
        
        # Load DistilBERT
        print("\n[2/3] Loading DistilBERT model...")
        self.distilbert_tokenizer = DistilBertTokenizer.from_pretrained(
            f'{model_dir}/distilbert'
        )
        self.distilbert_model = DistilBertForSequenceClassification.from_pretrained(
            f'{model_dir}/distilbert'
        )
        
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.distilbert_model.to(self.device)
        self.distilbert_model.eval()
        print(f"✓ DistilBERT loaded (device: {self.device})")
        
        # Load meta-learner if needed
        print("\n[3/3] Loading ensemble components...")
        if self.config['best_method'] == 'Stacking':
            with open(f'{model_dir}/stacking_meta_model.pkl', 'rb') as f:
                data = pickle.load(f)
                self.meta_model = data['meta_model']
                self.scaler = data['scaler']
        else:
            self.meta_model = None
        
        print("✓ Ensemble ready!")
        print("=" * 60 + "\n")
    
    def _load_cnn_model_compatible(self, model_dir):
        """Load CNN model with multiple compatibility methods"""
        model_path = f'{model_dir}/cnn_gru/model.h5'
        
        print(f"  Model path: {model_path}")
        print(f"  TensorFlow: {tf.__version__}")
        
        try:
            keras_version = keras.__version__
            print(f"  Keras: {keras_version}")
        except:
            print(f"  Keras: (version unavailable)")
        
        # Check what version the model was saved with
        try:
            import h5py
            with h5py.File(model_path, 'r') as f:
                if 'keras_version' in f.attrs:
                    saved_version = f.attrs['keras_version']
                    if isinstance(saved_version, bytes):
                        saved_version = saved_version.decode('utf-8')
                    print(f"  Model saved with Keras: {saved_version}")
                else:
                    print(f"  Model Keras version: Unknown")
        except Exception as e:
            print(f"  Could not read metadata: {str(e)[:40]}")
        
        # Try Method 1: TF 2.16+ way
        try:
            print("\n  Trying: TF 2.16+ loader...")
            import tensorflow.keras as tk
            model = tk.models.load_model(model_path, compile=False)
            print("  ✓ SUCCESS!")
            return model
        except Exception as e:
            print(f"  ✗ Failed: {str(e)[:80]}")
        
        # Try Method 2: Standard load
        try:
            print("\n  Trying: Standard keras loader...")
            model = keras.models.load_model(model_path, compile=False)
            print("  ✓ SUCCESS!")
            return model
        except Exception as e:
            print(f"  ✗ Failed: {str(e)[:80]}")
        
        # Try Method 3: Legacy TF 2.x
        try:
            print("\n  Trying: Legacy TF loader...")
            model = tf.keras.models.load_model(model_path, compile=False)
            print("  ✓ SUCCESS!")
            return model
        except Exception as e:
            print(f"  ✗ Failed: {str(e)[:80]}")
        
        # Try Method 4: Load with h5py and rebuild
        try:
            print("\n  Trying: Manual rebuild from H5...")
            import h5py
            with h5py.File(model_path, 'r') as f:
                if 'model_config' not in f.attrs:
                    raise ValueError("No model_config found in file")
                
                model_config = json.loads(f.attrs['model_config'])
                
                # Fix batch_shape issue in config
                if 'config' in model_config and 'layers' in model_config['config']:
                    for layer in model_config['config']['layers']:
                        layer_config = layer.get('config', {})
                        
                        # Fix InputLayer batch_shape -> shape
                        if layer.get('class_name') == 'InputLayer':
                            if 'batch_shape' in layer_config:
                                batch_shape = layer_config['batch_shape']
                                if batch_shape and batch_shape[0] is None:
                                    layer_config['shape'] = tuple(batch_shape[1:])
                                    del layer_config['batch_shape']
                            if 'batch_input_shape' in layer_config:
                                batch_shape = layer_config['batch_input_shape']
                                if batch_shape and batch_shape[0] is None:
                                    layer_config['shape'] = tuple(batch_shape[1:])
                                    del layer_config['batch_input_shape']
                
                # Rebuild model from fixed config
                model = keras.models.model_from_json(json.dumps(model_config))
                
                # Load weights
                model.load_weights(model_path)
                print("  ✓ SUCCESS!")
                return model
        except Exception as e:
            print(f"  ✗ Failed: {str(e)[:80]}")
        
        # All methods failed
        print("\n" + "="*60)
        print("  ❌ ALL LOADING METHODS FAILED")
        print("="*60)
        print("\n  EASIEST SOLUTION:")
        print("  Go to Kaggle → Add this cell at the end:")
        print()
        print("  ```python")
        print("  # Re-save for compatibility")
        print("  cnn_gru_model.save('cnn_fixed.h5')")
        print("  ")
        print("  # Download and replace:")
        print("  # ensemble_models/cnn_gru/model.h5")
        print("  ```")
        print()
        print("  OR install TensorFlow 2.16:")
        print("  pip install tensorflow==2.16.1")
        print("="*60)
        
        raise Exception("Cannot load model - see solutions above")
    
    def predict(self, texts, return_proba=False):
        """Predict toxicity"""
        if isinstance(texts, str):
            texts = [texts]
            single = True
        else:
            single = False
        
        pred1 = self._predict_cnn_gru(texts)
        pred2 = self._predict_distilbert(texts)
        
        if self.config['best_method'] == 'Stacking' and self.meta_model:
            X_meta = self._create_meta_features(pred1, pred2)
            X_meta_scaled = self.scaler.transform(X_meta)
            proba = self.meta_model.predict_proba(X_meta_scaled)[:, 1]
            threshold = self.config['stacking']['threshold']
        else:
            w1 = self.config['optimized_weighted']['w1']
            w2 = self.config['optimized_weighted']['w2']
            proba = w1 * pred1 + w2 * pred2
            threshold = self.config['optimized_weighted']['threshold']
        
        result = proba if return_proba else (proba >= threshold).astype(int)
        return result[0] if single else result
    
    def _predict_cnn_gru(self, texts):
        sequences = self.cnn_tokenizer.texts_to_sequences(texts)
        padded = keras.preprocessing.sequence.pad_sequences(
            sequences, 
            maxlen=self.config['cnn_gru_max_len'],
            padding='post'
        )
        preds = self.cnn_model.predict(padded, verbose=0)
        return preds.flatten() if preds.shape[1] == 1 else preds[:, 1]
    
    def _predict_distilbert(self, texts):
        all_preds = []
        for i in range(0, len(texts), 32):
            batch = texts[i:i+32]
            encoded = self.distilbert_tokenizer(
                batch, padding=True, truncation=True,
                max_length=self.config['distilbert_max_len'],
                return_tensors='pt'
            )
            with torch.no_grad():
                outputs = self.distilbert_model(
                    encoded['input_ids'].to(self.device),
                    encoded['attention_mask'].to(self.device)
                )
                probs = torch.softmax(outputs.logits, dim=1)[:, 1]
                all_preds.extend(probs.cpu().numpy())
        return np.array(all_preds)
    
    def _create_meta_features(self, p1, p2):
        return np.column_stack([
            p1, p2, (p1+p2)/2, np.abs(p1-p2),
            np.minimum(p1,p2), np.maximum(p1,p2),
            p1*p2, p1**2, p2**2
        ])

# ============================================================================
# LOAD MODEL
# ============================================================================

ensemble_model = None

try:
    ensemble_model = ToxicCommentEnsemble('ensemble_models')
except Exception as e:
    print(f"\n{'='*60}")
    print(f"MODEL LOADING FAILED!")
    print(f"{'='*60}")
    print(f"{e}")
    print(f"{'='*60}\n")

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def should_block_message(text, ml_prob, manual_toxicity):
    """
    Determine if message should be blocked entirely
    Returns: (should_block: bool, reason: str, combined_score: float)
    """
    # Combine scores
    combined_score = 1 * ml_prob + 1 * manual_toxicity
    
    # Check for profanity
    has_profanity = profanity_filter.contains_profanity(text)
    
    # STRICT BLOCKING: Block if contains ANY profanity
    if has_profanity:
        return True, "Message contains prohibited words", combined_score
    
    # Also block if ML model detects high toxicity
    if combined_score > 0.5:
        return True, "Message detected as highly toxic", combined_score
    
    return False, "Message approved", combined_score

# ============================================================================
# API ROUTES
# ============================================================================

@app.route("/api/v2/process-message", methods=["POST"])
def process_message():
    """Process message for toxicity"""
    
    if not ensemble_model:
        return jsonify({
            "error": "Model not loaded",
            "message": "Service unavailable. Check server logs."
        }), 503
    
    data = request.get_json(force=True, silent=True) or {}
    message = data.get("message", "")
    
    if not message or not isinstance(message, str):
        return jsonify({
            "error": "Invalid input",
            "message": "message (string) is required"
        }), 400
    
    if len(message.strip()) == 0:
        return jsonify({
            "error": "Invalid input",
            "message": "message cannot be empty"
        }), 400
    
    try:
        # ML Model prediction
        is_toxic_ml = ensemble_model.predict(message)
        prob_ml = ensemble_model.predict(message, return_proba=True)
        
        # Manual profanity check
        has_profanity = profanity_filter.contains_profanity(message)
        manual_toxicity = profanity_filter.get_toxicity_level(message)
        
        # Check if message should be blocked
        should_block, block_reason, combined_score = should_block_message(
            message, prob_ml, manual_toxicity
        )
        
        print(f"Message: {message[:50]}...")
        print(f"  ML Score: {prob_ml:.3f} | Manual: {manual_toxicity:.3f} | Combined: {combined_score:.3f}")
        print(f"  Profanity: {has_profanity} | Decision: {'BLOCKED' if should_block else 'APPROVED'}")
        
        if should_block:
            # BLOCK MESSAGE - Do not send
            return jsonify({
                "error": "Message blocked",
                "message": block_reason,
                "toxicity_score": float(combined_score),
                "ml_score": float(prob_ml),
                "manual_score": float(manual_toxicity),
                "contains_profanity": has_profanity,
                "status": "blocked",
                "blocked": True
            }), 403  # 403 Forbidden
        else:
            # APPROVE MESSAGE - Allow sending
            return jsonify({
                "needsReplacement": False,
                "message": message,
                "toxicity_score": float(combined_score),
                "ml_score": float(prob_ml),
                "manual_score": float(manual_toxicity),
                "contains_profanity": False,
                "status": "approved",
                "blocked": False
            }), 200
            
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "error": "Processing failed",
            "message": str(e)
        }), 500

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({
        "status": "healthy" if ensemble_model else "unhealthy",
        "model_loaded": ensemble_model is not None,
        "profanity_filter": "active"
    }), 200

@app.route("/api/model-info", methods=["GET"])
def model_info():
    if not ensemble_model:
        return jsonify({"error": "Model not loaded"}), 503
    return jsonify({
        "model": "Ensemble (CNN-GRU + DistilBERT)",
        "method": ensemble_model.config['best_method'],
        "device": str(ensemble_model.device),
        "tensorflow": tf.__version__,
        "profanity_filter": "enabled",
        "word_list_size": len(profanity_filter.bad_words),
        "status": "ready"
    }), 200

# Test endpoint for profanity filter
@app.route("/api/test-profanity", methods=["POST"])
def test_profanity():
    """Test profanity filter only (no ML model)"""
    data = request.get_json(force=True, silent=True) or {}
    message = data.get("message", "")
    
    if not message:
        return jsonify({"error": "message required"}), 400
    
    has_profanity = profanity_filter.contains_profanity(message)
    toxicity = profanity_filter.get_toxicity_level(message)
    censored = profanity_filter.censor_profanity(message)
    
    return jsonify({
        "original": message,
        "contains_profanity": has_profanity,
        "manual_toxicity_score": toxicity,
        "censored": censored
    }), 200

# Backward compatibility
@app.route("/api/process_message", methods=["POST"])
def process_message_old():
    return process_message()

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    
    print("\n" + "=" * 60)
    print(f"Flask API Starting")
    print(f"Port: {port}")
    print(f"Model: {'Loaded ✓' if ensemble_model else 'Not Loaded ✗'}")
    print(f"Profanity Filter: Active ({len(profanity_filter.bad_words)} words)")
    print("=" * 60 + "\n")
    
    app.run(host="0.0.0.0", port=port, debug=False)